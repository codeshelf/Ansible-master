/* Stub file for routines from nebmods.c */

int neb_free_callback_list(void) { return OK; }
int neb_unload_all_modules(int flags, int reason) { return OK; }
int neb_free_module_list(void) { return OK; }
int neb_deinit_modules(void) { return OK; }
int neb_add_module(char *filename, char *args, int should_be_loaded) { return OK; }
