#!/bin/bash
cd /usr/local/src/nagios/nagios-4.0.7
make install
make install-init
make install-config
make install-commandmode
make install-webconf
cd ../nagios-plugins-2.0.2
make install
cd ../nrpe-2.15
cp src/check_nrpe /opt/nagios/libexec/

